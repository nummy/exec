#!/usr/bin/env python
# coding=utf-8
import sys
import os

match_str_list = ["Idle", "System", "explorer.exe", "KTPrivilege.exe",
                  "StartupManager.exe", "LAVMsgBox.exe", "Lsf.exe",
                  "LAVService.exe", "LenovoDRS.exe", "LenovoPcManagerService.exe",
                  "LenovoTray.exe", "LeWindowService.exe", "CCSDK.exe",
                  "WinGather.exe", "ProtectionMain.exe"]

result_dict = {}


with open("lenovo.txt") as file:
    for line in file:
        ls = line.strip("\n").split(", ")
        index = ls[0].strip()
        time_val = ls[4].strip()
        weight_val = ls[6].strip()
        thread_name = ls[1].strip().split(" ")[0].strip()
        if thread_name in match_str_list:
            result_dict[thread_name] = []
            result_dict[thread_name].append(index)
            result_dict[thread_name].append(time_val)
            result_dict[thread_name].append(weight_val)
f = open('stat.txt', 'w')
for key, val in result_dict.items():
    f.write("%s, %s, %s, %s\n" % (val[0], key, val[1], val[2]))
f.close()
