import prompt,re
import math
from goody import type_as_str

class Point:
    pass



        

if __name__ == '__main__':
    #Simple tests before running driver
    #Put your own test code here to test Point before doing bsc tests

    print('Start simple testing')
    
    print()
    import driver
    
    driver.default_file_name = 'bsc1.txt'
#     driver.default_show_traceback = True
#     driver.default_show_exception = True
#     driver.default_show_exception_message = True
    driver.driver()
