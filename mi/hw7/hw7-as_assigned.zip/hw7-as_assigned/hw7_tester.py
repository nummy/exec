
import unittest

from route_analyzer import RouteAnalyzer


class Test(unittest.TestCase):


    def test_ConstructorShouldNotCrash(self):
        ''' (1) tests that the constructor does not throw an exception '''

        try:
            ra = RouteAnalyzer()
            crash = False
        except:
            crash = True

        self.assertFalse(crash, 'The route analyzer crashed in the constructor.')

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()