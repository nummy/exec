n = int(input())
left, right = []
l = int(input())
for _ in range(l):
    x, y, imp = map(float, input().split())
    left.append((x, y, imp))
r = int(input())
for _ in range(r):
    x, y, imp = map(float, input().split())
	right.append((x, y,imp))

