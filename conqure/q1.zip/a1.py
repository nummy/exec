n = int(input())
points = []
for _ in range(n):
    p = float(input())
    points.append(p)
