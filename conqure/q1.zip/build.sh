#! /usr/bin/env bash

# C
# clang a1.c -o a1

# C++
# clang++ a1.cc -o a1

# Java
# javac A1.java
