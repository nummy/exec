# Read in the number of vertices (n) and edges (m)
n = int(input())
m = int(input())

edges, queries = [], []

for _ in range(m):
    edges.append(input().split())

q = int(input())

for _ in range(q):
    queries.append(input().split())
	
# Print a `1` to stdout for each query. This section should be altered to instead print a `1` where the
# query indicates a connection and `0` else.

for _ in queries:
    print(int(True))
