#
#  PSP Assignment 2 - Provided file (Part I - list_function.py).
#  Remove this and place appropriate file comments here.
#
#  Modify this file to include your code solution.
#
#
# Write your function definitions in this file.
# Place your own comments in this file also.
#


# Function length() - place your own comments here...  : )
def length(my_list):

    # This line will eventually be removed - used for development purposes only.
    print("In function length()")

    # Place your code and comments here


# Function to_string() - place your own comments here...  : )
def to_string(my_list, sep=', '):

    # This line will eventually be removed - used for development purposes only.
    print("In function to_string()")

    # Place your code and comments here


# Function count() - place your own comments here...  : )
def count(my_list, value):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function count()")

    # Place your code and comments here


# Function find() - place your own comments here...  : )
def find(my_list, value):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function find()")

    # Place your code and comments here


# Function insert_value() - place your own comments here...  : )
def insert_value(my_list, value, insert_position):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function insert_value()")

    # Place your code and comments here


# Function remove_value() - place your own comments here...  : )
def remove_value(my_list, remove_position):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function remove_value()")

    # Place your code and comments here




