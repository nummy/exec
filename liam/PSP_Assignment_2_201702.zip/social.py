#
#  PSP Assignment 2 (Part II) - Provided file (social.py).
#  Remove this and place appropriate file comments here.
#
#  Modify this file to include your code solution.
#
#
# Write your code and function definitions in this file.
# Place your own comments in this file also.
#


# import profile
# import list_function  # Uncomment this when/if needed



# Function read_file() - place your own comments here...  : )
def read_file(filename, profile_list):
      
    # This line will eventually be removed - used for development purposes only.
    print("In function read_file()")

    # Place your code here

    
# Function display_summary() - place your own comments here...  : )
def display_summary(profile_list):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function display_summary()")

    # Place your code here

    
# Function write_to_file() - place your own comments here...  : )
def write_to_file(filename, profile_list):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function write_to_file()")

    # Place your code here

    
# Function find_profile() - place your own comments here...  : )    
def find_profile(profile_list, email):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function find_profile()")

    # Place your code here
    

# Function add_profile() - place your own comments here...  : )
def add_profile(profile_list):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function add_profile()")

    # Place your code here
    

# Function remove_profile() - place your own comments here...  : )
def remove_profile(profile_list):
    
    # This line will eventually be removed - used for development purposes only.
    print("In function remove_profile()")

    # Place your code here

	
# Function update_profile() - place your own comments here... : )
def update_profile():

    # This line will eventually be removed - used for development purposes only.
    print("In function update_profile()")

    # Place your code here


### Define a list to store Profile objects
profile_list = []


### Place your code here...  : )







### Terminating message 
print("\n\n-- Program terminating --\n")







